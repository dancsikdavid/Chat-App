const express = require('express');
const chatController = require('../controllers/chatController');
const router = express.Router();

router.get('/', chatController.listAllChats);
router.post('/', chatController.addChat);
router.put('/:id', chatController.updateChat);
router.delete('/:id', chatController.deleteChat);

module.exports = router;

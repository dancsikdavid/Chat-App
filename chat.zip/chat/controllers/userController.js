const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.listAllUsers = async (req, res) => {
  const users = await prisma.user.findMany();
   // res.json(users);
   return users;
};

exports.addUser = async (req, res) => {
  try {
    const { username, password, email, birthDate } = req.body;
    const newUser = await prisma.user.create({
      data: {
        username,
        password,
        email,
        birthDate: new Date(birthDate),
      },
    });
    res.json(newUser);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { username, password, email, birthDate } = req.body;
    const updatedUser = await prisma.user.update({
      where: { id: Number(id) },
      data: {
        username,
        password,
        email,
        birthDate: new Date(birthDate),
      },
    });
    res.json(updatedUser);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.user.delete({
      where: { id: Number(id) },
    });
    res.json({ message: 'A felhasználó sikeresen törölve lett!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

exports.listAllChats = async (req, res) => {
  try {
    const chats = await prisma.chat.findMany({
      include: {
        sender: true,
        to: true,
      },
    });
    res.json(chats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.addChat = async (req, res) => {
  try {
    const { content, senderId, toId } = req.body;
    const newChat = await prisma.chat.create({
      data: {
        content,
        senderId,
        toId,
      },
    });
    res.json(newChat);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateChat = async (req, res) => {
  try {
    const { id } = req.params;
    const { content } = req.body;
    const updatedChat = await prisma.chat.update({
      where: { id: Number(id) },
      data: { content },
    });
    res.json(updatedChat);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteChat = async (req, res) => {
  try {
    const { id } = req.params;
    await prisma.chat.delete({
      where: { id: Number(id) },
    });
    res.json({ message: 'A chat sikeresen törölve lett!' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
